# ReservaHotelRA3

Proyecto creado usando como base HotelReservasRA2 y agregando lo necesario de los proyectos pedido y delivery.

## Que se mantuvo de RA2

- Menu de consola.
- Modelos originales.
- Patrones builder, decorator, factory, adapter, facade, singleton y composite.
- Persistencia original por archivo.
- Servicios de reserva, pago, hotel y boleta.

## Que se agrego para RA3

- Proyecto Maven con Spring Boot.
- Configuracion JPA/MySQL en application.properties.
- Entidades JPA para el dominio de hotel:
  - ClienteEntity
  - UsuarioEntity
  - HabitacionEntity
  - ServicioAdicionalEntity
  - ReservaEntity
  - ReservaDetalleEntity
- Repositorios Spring Data JPA.
- Controladores REST basicos para listar, buscar, registrar, actualizar y eliminar.

## Endpoints principales

- /api/clientes
- /api/usuarios
- /api/habitaciones
- /api/servicios-adicionales
- /api/reservas

## Base de datos

La configuracion queda apuntando a:

jdbc:mysql://localhost:3307/dbhotelreservas

Usuario: root
Password: vacio

Si tu MySQL usa otro puerto, usuario o clave, cambia src/main/resources/application.properties.

## Arranque

Para arrancar como RA3 Spring Boot, ejecuta HotelReservasRa3Application.

Para usar el menu original de consola, ejecuta hotelreservasra2.main.Main.
