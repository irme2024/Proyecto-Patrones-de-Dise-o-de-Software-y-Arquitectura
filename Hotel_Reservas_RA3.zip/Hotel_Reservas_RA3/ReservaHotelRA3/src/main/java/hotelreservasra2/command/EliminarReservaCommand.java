package hotelreservasra2.command;

import hotelreservasra2.facade.SistemaHotelFacade;

public class EliminarReservaCommand implements Command {
    private final SistemaHotelFacade facade;
    private final String dni;

    public EliminarReservaCommand(SistemaHotelFacade facade, String dni) {
        this.facade = facade;
        this.dni = dni;
    }

    public void ejecutar() {
        this.facade.eliminarReservaPorDni(this.dni);
    }

    public void deshacer() {
        System.out.println("No se puede restaurar automaticamente la reserva eliminada.");
    }
}
