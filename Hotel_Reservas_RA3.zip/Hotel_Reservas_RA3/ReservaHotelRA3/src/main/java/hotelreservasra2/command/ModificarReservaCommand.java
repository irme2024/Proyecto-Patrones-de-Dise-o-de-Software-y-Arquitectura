package hotelreservasra2.command;

public class ModificarReservaCommand {
    public ModificarReservaCommand() {
    }

    public void ejecutar() {
    }

    public void deshacer() {
    }
}
