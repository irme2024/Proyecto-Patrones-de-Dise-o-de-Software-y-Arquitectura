package hotelreservasra2.command;

import java.util.Stack;

public class Invoker {
    private final Stack<Command> historial = new Stack();
    private final Stack<Command> rehacer = new Stack();

    public Invoker() {
    }

    public void ejecutar(Command comando) {
        comando.ejecutar();
        this.historial.push(comando);
        this.rehacer.clear();
    }

    public void deshacer() {
        if (!this.historial.isEmpty()) {
            Command cmd = (Command)this.historial.pop();
            cmd.deshacer();
            this.rehacer.push(cmd);
            System.out.println("Operacion deshecha.");
        } else {
            System.out.println("No hay operaciones para deshacer.");
        }

    }

    public void rehacer() {
        if (!this.rehacer.isEmpty()) {
            Command cmd = (Command)this.rehacer.pop();
            cmd.ejecutar();
            this.historial.push(cmd);
            System.out.println("Operacion rehecha.");
        } else {
            System.out.println("No hay operaciones para rehacer.");
        }

    }
}

