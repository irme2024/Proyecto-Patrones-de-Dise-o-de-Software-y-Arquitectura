package hotelreservasra2.command;

import hotelreservasra2.facade.SistemaHotelFacade;
import hotelreservasra2.model.Reserva;

public class CrearReservaCommand implements Command {
    private final SistemaHotelFacade facade;
    private final Reserva reserva;
    private final int metodo;
    private final double total;

    public CrearReservaCommand(SistemaHotelFacade facade, Reserva reserva, int metodo, double total) {
        this.facade = facade;
        this.reserva = reserva;
        this.metodo = metodo;
        this.total = total;
    }

    public void ejecutar() {
        this.facade.registrarReservaCompleta(this.reserva, this.metodo, this.total);
    }

    public void deshacer() {
        this.facade.eliminarReservaPorDni(this.reserva.getCliente().getDni());
    }
}

