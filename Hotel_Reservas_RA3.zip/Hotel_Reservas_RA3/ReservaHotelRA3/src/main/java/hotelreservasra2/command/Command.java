package hotelreservasra2.command;

public interface Command {
    void ejecutar();

    void deshacer();
}
