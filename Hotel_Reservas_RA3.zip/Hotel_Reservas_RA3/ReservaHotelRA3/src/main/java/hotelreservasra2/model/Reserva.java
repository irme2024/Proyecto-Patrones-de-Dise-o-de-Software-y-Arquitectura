package hotelreservasra2.model;

import hotelreservasra2.decorator.HabitacionBase;
import hotelreservasra2.state.EstadoReserva;
import hotelreservasra2.state.PendienteState;
import hotelreservasra2.strategy.StrategyTarifa;
import hotelreservasra2.strategy.StrategyTarifa;
import hotelreservasra2.strategy.TarifaNormal;
import java.io.Serializable;

public class Reserva implements Serializable {
    private static final long serialVersionUID = 1L;
    private Cliente cliente;
    private HabitacionBase habitacion;
    private String metodoPago;
    private int noches;
    private int numeroHabitacion;
    private String fechaIngreso;
    private String fechaSalida;
    private StrategyTarifa estrategiaTarifa = new TarifaNormal();
    private EstadoReserva estadoReserva = new PendienteState();

    public Reserva() {
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setHabitacion(HabitacionBase habitacion) {
        this.habitacion = habitacion;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public void setNoches(int noches) {
        this.noches = noches;
    }

    public void setNumeroHabitacion(int numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public void setFechaIngreso(String fechaIngreso) {
        this.fechaIngreso = fechaIngreso;
    }

    public void setFechaSalida(String fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public void setEstrategiaTarifa(StrategyTarifa estrategiaTarifa) {
        this.estrategiaTarifa = estrategiaTarifa;
    }

    public void setEstadoReserva(EstadoReserva estadoReserva) {
        this.estadoReserva = estadoReserva;
    }

    public Cliente getCliente() {
        return this.cliente;
    }

    public HabitacionBase getHabitacion() {
        return this.habitacion;
    }

    public int getNoches() {
        return this.noches;
    }

    public String getMetodoPago() {
        return this.metodoPago;
    }

    public int getNumeroHabitacion() {
        return this.numeroHabitacion;
    }

    public String getFechaIngreso() {
        return this.fechaIngreso;
    }

    public String getFechaSalida() {
        return this.fechaSalida;
    }

    public StrategyTarifa getEstrategiaTarifa() {
        return this.estrategiaTarifa;
    }

    public double calcularTotal() {
        return this.estrategiaTarifa.calcular(this.habitacion.getCoste() * (double)this.noches);
    }

    public EstadoReserva getEstadoReserva() {
        return this.estadoReserva;
    }

    public String obtenerEstado() {
        return this.estadoReserva.getNombre();
    }

    public String toString() {
        String var10000 = this.cliente.getNombre();
        return "Cliente: " + var10000 + " (" + this.cliente.getDni() + ") | Hab: " + this.numeroHabitacion + " | Rango: " + this.fechaIngreso + " al " + this.fechaSalida + " | Estado: " + this.obtenerEstado() + " | Desc: " + this.habitacion.getDescripcion() + " | Estadia: " + this.noches + " noches | Total: S/. " + this.calcularTotal() + " | Pago: " + this.metodoPago;
    }
}