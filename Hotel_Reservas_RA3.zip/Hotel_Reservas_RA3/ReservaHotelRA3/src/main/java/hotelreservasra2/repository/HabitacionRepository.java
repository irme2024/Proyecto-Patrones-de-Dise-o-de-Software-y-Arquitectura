package hotelreservasra2.repository;

import hotelreservasra2.entity.HabitacionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HabitacionRepository extends JpaRepository<HabitacionEntity, Integer> {
}
