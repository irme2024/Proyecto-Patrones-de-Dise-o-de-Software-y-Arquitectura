package hotelreservasra2.repository;

import hotelreservasra2.entity.ServicioAdicionalEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ServicioAdicionalRepository extends JpaRepository<ServicioAdicionalEntity, Integer> {
}
