package hotelreservasra2.repository;

import hotelreservasra2.entity.ReservaDetalleEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservaDetalleRepository extends JpaRepository<ReservaDetalleEntity, Integer> {
}
