package hotelreservasra2.observer;

public class ClienteObserver implements Observer {
    public ClienteObserver() {
    }

    public void actualizar(String mensaje) {
        System.out.println("[CLIENTE] " + mensaje);
    }
}
