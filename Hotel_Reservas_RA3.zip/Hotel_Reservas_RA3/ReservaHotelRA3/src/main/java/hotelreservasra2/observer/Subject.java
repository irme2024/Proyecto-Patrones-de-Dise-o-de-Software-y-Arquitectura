package hotelreservasra2.observer;

public interface Subject {
    void agregarObserver(Observer var1);

    void eliminarObserver(Observer var1);

    void notificarObservers(String var1);
}
