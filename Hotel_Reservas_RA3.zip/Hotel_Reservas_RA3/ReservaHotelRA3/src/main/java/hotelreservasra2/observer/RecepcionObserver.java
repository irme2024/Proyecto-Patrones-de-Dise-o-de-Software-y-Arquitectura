package hotelreservasra2.observer;

public class RecepcionObserver implements Observer {
    public RecepcionObserver() {
    }

    public void actualizar(String mensaje) {
        System.out.println("[RECEPCION] " + mensaje);
    }
}
