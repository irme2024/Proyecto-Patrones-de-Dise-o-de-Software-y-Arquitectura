package hotelreservasra2.observer;

public class AdministracionObserver implements Observer {
    public AdministracionObserver() {
    }

    public void actualizar(String mensaje) {
        System.out.println("[ADMINISTRACION] " + mensaje);
    }
}
