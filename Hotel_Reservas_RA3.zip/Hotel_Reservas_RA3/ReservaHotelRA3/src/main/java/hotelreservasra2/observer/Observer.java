package hotelreservasra2.observer;

public interface Observer {
    void actualizar(String var1);
}
