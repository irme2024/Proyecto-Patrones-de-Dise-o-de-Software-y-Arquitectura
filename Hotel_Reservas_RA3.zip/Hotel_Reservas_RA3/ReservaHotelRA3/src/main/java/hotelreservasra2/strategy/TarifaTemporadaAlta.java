package hotelreservasra2.strategy;

public class TarifaTemporadaAlta implements StrategyTarifa{
    public TarifaTemporadaAlta() {
    }

    public double calcular(double montoBase) {
        return montoBase * 1.2;
    }
}
