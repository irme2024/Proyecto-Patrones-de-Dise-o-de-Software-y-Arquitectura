package hotelreservasra2.strategy;

public interface StrategyTarifa {
    double calcular(double var1);
}
