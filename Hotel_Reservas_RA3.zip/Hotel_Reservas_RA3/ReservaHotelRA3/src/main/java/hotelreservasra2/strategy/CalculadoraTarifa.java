package hotelreservasra2.strategy;

import hotelreservasra2.model.Reserva;

public class CalculadoraTarifa {
    public CalculadoraTarifa() {
    }

    public static double calcular(Reserva reserva) {
        return reserva.getEstrategiaTarifa().calcular(reserva.getHabitacion().getCoste() * (double)reserva.getNoches());
    }
}
