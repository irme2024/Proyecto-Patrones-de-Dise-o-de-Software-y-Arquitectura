package hotelreservasra2.strategy;

public class TarifaCorporativa implements StrategyTarifa{

    public TarifaCorporativa() {
    }

    @Override
    public double calcular(double montoBase) {
        return montoBase * (double)0.75F;
    }
}
