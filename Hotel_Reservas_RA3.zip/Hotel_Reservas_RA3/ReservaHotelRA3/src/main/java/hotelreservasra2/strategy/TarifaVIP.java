package hotelreservasra2.strategy;

public class TarifaVIP implements StrategyTarifa{
    public TarifaVIP() {
    }

    public double calcular(double montoBase) {
        return montoBase * 0.85;
    }
}
