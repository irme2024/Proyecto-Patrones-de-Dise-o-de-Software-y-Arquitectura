package hotelreservasra2.strategy;

public class TarifaNormal implements StrategyTarifa {
    public TarifaNormal() {
    }

    public double calcular(double montoBase) {

        return montoBase;
    }
}
