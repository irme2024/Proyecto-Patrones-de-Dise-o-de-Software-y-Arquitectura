package hotelreservasra2.state;

public class ConfirmadaState implements EstadoReserva {
    public ConfirmadaState() {
    }

    public String getNombre() {
        return "Confirmada";
    }
}
