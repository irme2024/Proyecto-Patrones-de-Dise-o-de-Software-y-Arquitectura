package hotelreservasra2.state;

public class CheckInState implements EstadoReserva {
    public CheckInState() {
    }

    public String getNombre() {
        return "Check-In";
    }
}
