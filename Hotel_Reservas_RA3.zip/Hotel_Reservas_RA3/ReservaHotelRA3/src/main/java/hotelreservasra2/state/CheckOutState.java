package hotelreservasra2.state;

public class CheckOutState implements EstadoReserva {
    public CheckOutState() {
    }

    public String getNombre() {
        return "Check-Out";
    }
}
