package hotelreservasra2.state;

public interface EstadoReserva {
    String getNombre();
}
