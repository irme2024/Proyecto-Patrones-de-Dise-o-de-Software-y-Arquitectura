package hotelreservasra2.state;

public class PendienteState implements EstadoReserva {
    public PendienteState() {
    }

    public String getNombre() {
        return "Pendiente";
    }
}
