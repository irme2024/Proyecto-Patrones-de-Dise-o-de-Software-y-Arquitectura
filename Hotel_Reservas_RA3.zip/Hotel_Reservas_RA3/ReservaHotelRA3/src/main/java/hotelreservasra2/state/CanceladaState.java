package hotelreservasra2.state;

public class CanceladaState implements EstadoReserva {
    public CanceladaState() {
    }

    public String getNombre() {
        return "Cancelada";
    }
}
