package hotelreservasra2.controller;

import hotelreservasra2.entity.ServicioAdicionalEntity;
import hotelreservasra2.repository.ServicioAdicionalRepository;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/servicios-adicionales")
public class ServicioAdicionalController {

    private final ServicioAdicionalRepository repository;

    public ServicioAdicionalController(ServicioAdicionalRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<ServicioAdicionalEntity> listar() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ServicioAdicionalEntity> buscar(@PathVariable Integer id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ServicioAdicionalEntity guardar(@RequestBody ServicioAdicionalEntity entity) {
        return repository.save(entity);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ServicioAdicionalEntity> actualizar(@PathVariable Integer id, @RequestBody ServicioAdicionalEntity entity) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        entity.setId(id);
        return ResponseEntity.ok(repository.save(entity));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
