package hotelreservasra2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelReservasRa3Application {

    public static void main(String[] args) {
        SpringApplication.run(HotelReservasRa3Application.class, args);
    }
}
