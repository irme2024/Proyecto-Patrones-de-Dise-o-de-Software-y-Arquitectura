package hotelreservasra2.model;

import hotelreservasra2.decorator.HabitacionBase;
import java.io.Serializable;

public class Reserva implements Serializable {
    private static final long serialVersionUID = 1L;
    private Cliente cliente;
    private HabitacionBase habitacion;
    private String metodoPago;
    private int noches;
    private int numeroHabitacion;
    private String fechaIngreso; // Nuevo campo
    private String fechaSalida;  // Nuevo campo

    // Setters
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public void setHabitacion(HabitacionBase habitacion) { this.habitacion = habitacion; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    public void setNoches(int noches) { this.noches = noches; }
    public void setNumeroHabitacion(int numeroHabitacion) { this.numeroHabitacion = numeroHabitacion; }
    public void setFechaIngreso(String fechaIngreso) { this.fechaIngreso = fechaIngreso; } // Añadido
    public void setFechaSalida(String fechaSalida) { this.fechaSalida = fechaSalida; }   // Añadido
    
    // Getters
    public Cliente getCliente() { return cliente; }
    public HabitacionBase getHabitacion() { return habitacion; }
    public int getNoches() { return noches; }
    public String getMetodoPago() { return metodoPago; }
    public int getNumeroHabitacion() { return numeroHabitacion; }
    public String getFechaIngreso() { return fechaIngreso; } // Añadido
    public String getFechaSalida() { return fechaSalida; }   // Añadido

    @Override
    public String toString() {
        return "Cliente: " + cliente.getNombre() + " (" + cliente.getDni() + ") | " +
               "Hab: " + numeroHabitacion + " | " +
               "Rango: " + fechaIngreso + " al " + fechaSalida + " | " + // Actualizado
               "Desc: " + habitacion.getDescripcion() + " | " +
               "Estadia: " + noches + " noches | Total: S/. " + (habitacion.getCoste() * noches) + " | Pago: " + metodoPago;
    }
}