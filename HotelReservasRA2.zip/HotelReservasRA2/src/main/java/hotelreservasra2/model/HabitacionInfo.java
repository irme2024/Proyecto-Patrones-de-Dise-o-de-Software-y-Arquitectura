package hotelreservasra2.model;
import java.io.Serializable;

public class HabitacionInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    private int numero;
    private String tipo;
    private double precioTotal;
    public HabitacionInfo(int numero, String tipo, double precioTotal) {
        this.numero = numero; this.tipo = tipo; this.precioTotal = precioTotal;
    }
    public int getNumero() { return numero; }
    public String getTipo() { return tipo; }
    public double getPrecioTotal() { return precioTotal; }
}
