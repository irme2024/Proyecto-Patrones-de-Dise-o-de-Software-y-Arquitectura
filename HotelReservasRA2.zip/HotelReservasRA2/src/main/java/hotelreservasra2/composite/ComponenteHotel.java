package hotelreservasra2.composite;
public interface ComponenteHotel { void mostrarEstructura(); }
