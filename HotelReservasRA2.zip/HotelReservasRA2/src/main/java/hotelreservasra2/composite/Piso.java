package hotelreservasra2.composite;
import java.util.ArrayList;
import java.util.List;

public class Piso implements ComponenteHotel {
    private final int numeroPiso;
    private final List<ComponenteHotel> componentes = new ArrayList<>();
    public Piso(int numeroPiso) { this.numeroPiso = numeroPiso; }
    public void añadir(ComponenteHotel c) { componentes.add(c); }
    public void mostrarEstructura() {
        System.out.println("  |-- Piso " + numeroPiso);
        for (ComponenteHotel c : componentes) { c.mostrarEstructura(); }
    }
}
