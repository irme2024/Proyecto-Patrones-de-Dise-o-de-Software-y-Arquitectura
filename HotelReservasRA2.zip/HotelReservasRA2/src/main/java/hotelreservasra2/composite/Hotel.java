package hotelreservasra2.composite;
import java.util.ArrayList;
import java.util.List;

public class Hotel implements ComponenteHotel {
    private final String nombre;
    private final List<ComponenteHotel> pisos = new ArrayList<>();
    public Hotel(String nombre) { this.nombre = nombre; }
    public void añadirPiso(ComponenteHotel p) { pisos.add(p); }
    public void mostrarEstructura() {
        System.out.println("Estructura del Hotel: " + nombre);
        for (ComponenteHotel p : pisos) { p.mostrarEstructura(); }
    }
}
