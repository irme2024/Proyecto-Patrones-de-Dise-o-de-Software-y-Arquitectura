package hotelreservasra2.composite;

public class Habitacion implements ComponenteHotel {
    private final int numero;
    private final String descripcion;

    // Nuevo constructor (para el registro con tipo)
    public Habitacion(int numero, String descripcion) { 
        this.numero = numero; 
        this.descripcion = descripcion; 
    }

    // Sobrecarga: Constructor antiguo (mantiene compatibilidad)
    public Habitacion(int numero) { 
        this.numero = numero; 
        this.descripcion = "Habitacion Base"; // Valor predeterminado
    }

    public void mostrarEstructura() { 
        System.out.println("      |-- [Habitacion Nro " + numero + " - " + descripcion + "]"); 
    }

    public int getNumero() { return numero; }
    public String getDescripcion() { return descripcion; }
}