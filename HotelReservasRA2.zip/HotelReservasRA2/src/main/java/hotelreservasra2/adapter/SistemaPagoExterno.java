package hotelreservasra2.adapter;
public class SistemaPagoExterno {
    public void enviarTransaccionExterna(double cantidad, String divisa) {
        System.out.println("[Pasarela Externa] Procesando cobro de: " + cantidad + " " + divisa);
    }
}
