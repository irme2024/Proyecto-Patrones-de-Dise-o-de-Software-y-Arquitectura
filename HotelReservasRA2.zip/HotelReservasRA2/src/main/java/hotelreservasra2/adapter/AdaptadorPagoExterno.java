package hotelreservasra2.adapter;
import hotelreservasra2.factory.MetodoPago;
public class AdaptadorPagoExterno implements MetodoPago {
    private final SistemaPagoExterno sistemaExterno;
    public AdaptadorPagoExterno(SistemaPagoExterno sistemaExterno) { this.sistemaExterno = sistemaExterno; }
    public void procesarPago(double monto) { sistemaExterno.enviarTransaccionExterna(monto, "PEN"); }
}
