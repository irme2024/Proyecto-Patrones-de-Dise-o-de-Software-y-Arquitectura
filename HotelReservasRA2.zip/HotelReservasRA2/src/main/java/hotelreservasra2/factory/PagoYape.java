package hotelreservasra2.factory;
public class PagoYape implements MetodoPago {
    public void procesarPago(double m) { System.out.println("Yapeado S/ " + m + " correctamente."); }
}
