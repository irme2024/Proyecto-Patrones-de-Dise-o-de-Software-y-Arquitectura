package hotelreservasra2.factory;
public interface MetodoPago { void procesarPago(double monto); }
