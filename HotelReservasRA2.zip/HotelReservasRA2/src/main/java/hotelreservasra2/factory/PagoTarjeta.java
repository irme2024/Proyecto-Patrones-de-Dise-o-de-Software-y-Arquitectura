package hotelreservasra2.factory;
public class PagoTarjeta implements MetodoPago {
    public void procesarPago(double m) { System.out.println("Cobrado S/ " + m + " exitosamente con Tarjeta."); }
}
