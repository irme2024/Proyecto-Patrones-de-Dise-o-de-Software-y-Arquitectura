package hotelreservasra2.factory;
public class PagoEfectivo implements MetodoPago {
    public void procesarPago(double m) { System.out.println("Pago en efectivo en recepcion: S/ " + m); }
}
