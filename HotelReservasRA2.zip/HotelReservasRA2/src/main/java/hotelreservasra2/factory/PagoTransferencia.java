package hotelreservasra2.factory;
public class PagoTransferencia implements MetodoPago {
    public void procesarPago(double m) { System.out.println("Transferencia verificada por S/ " + m); }
}
