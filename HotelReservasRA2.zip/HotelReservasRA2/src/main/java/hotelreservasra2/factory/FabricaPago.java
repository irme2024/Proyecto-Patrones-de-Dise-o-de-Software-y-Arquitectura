package hotelreservasra2.factory;
public class FabricaPago {
    public static MetodoPago crearMetodoPago(int opcion) {
        return switch (opcion) {
            case 1 -> new PagoEfectivo();
            case 2 -> new PagoTarjeta();
            case 3 -> new PagoYape();
            case 4 -> new PagoTransferencia();
            default -> new PagoEfectivo();
        };
    }
}
