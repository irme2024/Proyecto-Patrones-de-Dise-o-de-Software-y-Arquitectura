package hotelreservasra2.servicio;

import hotelreservasra2.model.Reserva;
import java.util.ArrayList;
import java.util.List;

public class ServicioBoleta {

    private static class ItemFactura {
        String descripcion;
        double totalItem; // Precio final (incluye IGV)

        ItemFactura(String descripcion, double totalItem) {
            this.descripcion = descripcion;
            this.totalItem = totalItem;
        }
    }

    public void generarTicket(Reserva r, String codigoBoleta) {
        System.out.println("\n=========================================================");
        System.out.println("               HOTEL TRADICION & CONFORT                 ");
        System.out.println("             R.U.C. Nro. 20457812349                     ");
        System.out.println("               BOLETA DE VENTA ELECTRONICA               ");
        System.out.println("=========================================================");
        System.out.println(" SERIE: EB01          NRO: " + codigoBoleta);
        System.out.println(" Fecha de Emision:    " + (r.getFechaIngreso() != null ? r.getFechaIngreso() : "N/D"));
        System.out.println(" Cliente:             " + r.getCliente().getNombre().toUpperCase());
        System.out.println(" DNI:                 " + r.getCliente().getDni());
        System.out.println("---------------------------------------------------------");
        
        String fIngreso = (r.getFechaIngreso() != null) ? r.getFechaIngreso() : "N/D";
        String fSalida = (r.getFechaSalida() != null) ? r.getFechaSalida() : "N/D";
        System.out.printf(" F. INGRESO: %-12s     F. SALIDA: %-12s\n", fIngreso, fSalida);
        System.out.println(" Habitacion: %-12s     Estadia:   %d noches".formatted(r.getNumeroHabitacion(), r.getNoches()));
        System.out.println("---------------------------------------------------------");
        System.out.println(" DESCRIPCION                                TOTAL (S/.)  ");
        System.out.println("---------------------------------------------------------");
        
        List<ItemFactura> detalles = calcularDesglose(r.getHabitacion().getDescripcion(), r.getNoches());
        
        double totalGeneral = 0;
        for (ItemFactura item : detalles) {
            System.out.printf(" %-41s %8.2f\n", item.descripcion, item.totalItem);
            totalGeneral += item.totalItem;
        }
        
        // Cálculos Tributarios (Extracción del 18% del total)
        double gravado = totalGeneral / 1.18;
        double igv = totalGeneral - gravado;
        
        System.out.println("---------------------------------------------------------");
        System.out.printf(" OP. GRAVADA:                               S/. %8.2f\n", gravado);
        System.out.printf(" I.G.V. (18%%):                              S/. %8.2f\n", igv);
        System.out.printf(" IMPORTE TOTAL:                             S/. %8.2f\n", totalGeneral);
        System.out.println("---------------------------------------------------------");
        System.out.printf(" METODO DE PAGO: %-39s\n", r.getMetodoPago().toUpperCase());
        System.out.println("=========================================================");
        System.out.println(" Representacion impresa de la Boleta de Venta Electronica");
        System.out.println("       Consulte su comprobante en www.hoteltyc.gob.pe     ");
        System.out.println("               Gracias por su preferencia!              ");
        System.out.println("=========================================================\n");
    }

    private List<ItemFactura> calcularDesglose(String desc, int noches) {
        List<ItemFactura> lista = new ArrayList<>();
        
        double tarifaBaseHabitacion = 110.00; 
        lista.add(new ItemFactura("Habitacion Simple (" + noches + " noches)", tarifaBaseHabitacion * noches));
        
        if (desc.contains("Desayuno")) {
            lista.add(new ItemFactura("+ Desayuno Buffet (S/. 12.00 x noche)", 12.00 * noches));
        }
        if (desc.contains("WiFi") || desc.contains("Wifi")) {
            lista.add(new ItemFactura("+ WiFi (S/. 10.00 x noche)", 10.00 * noches));
        }
        if (desc.contains("Spa")) {
            lista.add(new ItemFactura("+ Acceso Spa (S/. 15.00 x noche)", 15.00 * noches));
        }
        
        return lista;
    }
}