package hotelreservasra2.servicio;
import hotelreservasra2.factory.FabricaPago;
import hotelreservasra2.factory.MetodoPago;

public class ServicioPago {
    public void procesarCobro(int opPago, double monto) {
        MetodoPago mp = FabricaPago.crearMetodoPago(opPago);
        mp.procesarPago(monto);
    }
}
