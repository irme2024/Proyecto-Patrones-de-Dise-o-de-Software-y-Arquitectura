package hotelreservasra2.servicio;
import hotelreservasra2.composite.*;

public class ServicioHotel {
    private final Hotel miHotel;
    public ServicioHotel() {
        this.miHotel = new Hotel("Paradiso Enterprise");
        Piso p1 = new Piso(1); p1.añadir(new Habitacion(101)); p1.añadir(new Habitacion(102));
        Piso p2 = new Piso(2); p2.añadir(new Habitacion(201));
        miHotel.añadirPiso(p1); miHotel.añadirPiso(p2);
    }
    public void verEstructura() { miHotel.mostrarEstructura(); }
}
