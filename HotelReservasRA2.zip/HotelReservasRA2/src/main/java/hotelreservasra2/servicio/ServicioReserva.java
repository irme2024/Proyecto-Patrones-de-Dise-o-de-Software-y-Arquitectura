package hotelreservasra2.servicio;

import hotelreservasra2.model.Reserva;
import hotelreservasra2.singleton.GestorReservas;
import hotelreservasra2.persistencia.ArchivoReservas;
import java.util.ArrayList;
import java.util.List;

public class ServicioReserva {
    // Tarifas Centralizadas
    private static final double TARIFA_BASE = 40.0;
    private static final double TARIFA_PREMIUM = 80.0;
    private static final double PRECIO_DESAYUNO = 12.0;
    private static final double PRECIO_SPA = 15.0;
    private static final double PRECIO_WIFI = 10.0;

    private final GestorReservas gestor = GestorReservas.getInstancia();
    private final ArchivoReservas archivo = new ArchivoReservas();

    public void inicializarSistema() {
        gestor.limpiarYcargar(archivo.cargarReservas());
    }

    public void registrarNuevaReserva(Reserva r) {
        gestor.registrarReserva(r);
        archivo.guardarReservas(gestor.getReservas());
    }

    public void listarReservas() {
        List<Reserva> actuales = gestor.getReservas();
        if (actuales.isEmpty()) {
            System.out.println("No hay reservas registradas.");
            return;
        }

        String linea = "+--------+------------------+------------+-----------------------+---------+--------------------------+--------------+";
        System.out.println(linea);
        System.out.printf("| %-6s | %-16s | %-10s | %-21s | %-7s | %-24s | %-12s |\n", 
                "BOLETA", "  CLIENTE", "  DNI", "RANGO ESTADIA", "HAB.N", "   SERVICIOS", "  TOTAL");
        System.out.println(linea);

        int contador = 1;
        for (Reserva r : actuales) {
            String codigoBoleta = String.format("B%03d", contador++);
            String clienteNom = (r.getCliente().getNombre().length() > 16) ? r.getCliente().getNombre().substring(0, 13) + "..." : r.getCliente().getNombre();
            String rango = (r.getFechaIngreso() != null && r.getFechaSalida() != null) 
                        ? r.getFechaIngreso().substring(0, 5) + " al " + r.getFechaSalida().substring(0, 5) 
                        : r.getNoches() + " noches";

            
            boolean esPremium = r.getHabitacion().getDescripcion().contains("Premium");
            List<String> servicios = desglosarServiciosConPrecios(r.getHabitacion().getDescripcion(), esPremium);
            double totalReserva = calcularTotalReserva(r);

            // Fila principal
            System.out.printf("| %-6s | %-16s | %-10s | %-21s | %-7d | %-24s | S/. %-9.2f |\n",
                    codigoBoleta, clienteNom, r.getCliente().getDni(), rango, r.getNumeroHabitacion(), 
                    servicios.get(0), totalReserva);

            // Filas adicionales
            for (int i = 1; i < servicios.size(); i++) {
                System.out.printf("| %-6s | %-16s | %-10s | %-21s | %-7s | %-24s | %-12s |\n",
                        "", "", "", "", "", servicios.get(i), "");
            }
            System.out.println(linea);
        }
    }

    private List<String> desglosarServiciosConPrecios(String desc, boolean esPremium) {
        List<String> lineas = new ArrayList<>();
        String tipo = esPremium ? "Premium" : "Base";
        double precioBase = esPremium ? TARIFA_PREMIUM : TARIFA_BASE;
        
        lineas.add("Hab. " + tipo + " (S/." + String.format("%.2f", precioBase) + ")");
        if (desc.contains("Desayuno")) lineas.add("+ Desayuno (S/." + String.format("%.2f", PRECIO_DESAYUNO) + ")");
        if (desc.contains("Spa"))      lineas.add("+ Spa      (S/." + String.format("%.2f", PRECIO_SPA) + ")");
        if (desc.contains("WiFi"))     lineas.add("+ WiFi     (S/." + String.format("%.2f", PRECIO_WIFI) + ")");
        return lineas;
    }

    private double calcularTotalReserva(Reserva r) {
        boolean esPremium = r.getHabitacion().getDescripcion().contains("Premium");
        double total = (esPremium ? TARIFA_PREMIUM : TARIFA_BASE) * r.getNoches();
        
        String desc = r.getHabitacion().getDescripcion();
        if (desc.contains("Desayuno")) total += (PRECIO_DESAYUNO * r.getNoches());
        if (desc.contains("Spa"))      total += (PRECIO_SPA * r.getNoches());
        if (desc.contains("WiFi"))     total += (PRECIO_WIFI * r.getNoches());
        return total;
    }

    public boolean estaHabitacionOcupada(int numHab) { 
        return gestor.getReservas().stream().anyMatch(r -> r.getNumeroHabitacion() == numHab); 
    }
    
    public GestorReservas getGestor() { return this.gestor; }
    
    public boolean eliminarPorDni(String dni) {
        boolean rest = gestor.eliminarPorDni(dni);
        if (rest) archivo.guardarReservas(gestor.getReservas()); 
        return rest;
    }
}