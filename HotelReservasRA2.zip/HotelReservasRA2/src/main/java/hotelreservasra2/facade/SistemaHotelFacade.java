package hotelreservasra2.facade;

import hotelreservasra2.model.Reserva;
import hotelreservasra2.servicio.*;

public class SistemaHotelFacade {
    private final ServicioHotel servHotel = new ServicioHotel();
    private final ServicioPago servPago = new ServicioPago();
    private final ServicioReserva servReserva = new ServicioReserva();
    private final ServicioBoleta servBoleta = new ServicioBoleta();

    public void inicializar() { servReserva.inicializarSistema(); }

    public void registrarReservaCompleta(Reserva r, int opPago, double total) {
        servPago.procesarCobro(opPago, total);
        servReserva.registrarNuevaReserva(r);
    }

    public void mostrarReservas() { servReserva.listarReservas(); }
    public boolean eliminarReservaPorDni(String dni) { return servReserva.eliminarPorDni(dni); }
    public void mostrarEstructuraHotel() { servHotel.verEstructura(); }
    public boolean verificarDisponibilidadHabitacion(int numHab) { return servReserva.estaHabitacionOcupada(numHab); }

    // ESTE MÉTODO DEBE CLONARSE EXACTAMENTE ASÍ
    public void imprimirBoletaPorCriterio(String criterio) {
        int contador = 1;
        Reserva encontrada = null;
        String codigoBoletaEncontrada = "";
        
        for (Reserva r : servReserva.getGestor().getReservas()) {
            String codigoBoletaActual = String.format("B%03d", contador);
            
            if (r.getCliente().getDni().equalsIgnoreCase(criterio) || codigoBoletaActual.equalsIgnoreCase(criterio)) {
                encontrada = r;
                codigoBoletaEncontrada = codigoBoletaActual;
                break;
            }
            contador++;
        }

        if (encontrada != null) {
            servBoleta.generarTicket(encontrada, codigoBoletaEncontrada);
        } else {
            System.out.println("[ERROR] No se encontro ninguna reserva para el DNI o Boleta: " + criterio);
        }
    }
}