package hotelreservasra2.singleton;
import hotelreservasra2.model.Reserva;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GestorReservas {
    private static GestorReservas instancia;
    private final List<Reserva> reservas;
    
    private GestorReservas() { reservas = new ArrayList<>(); }
    
    public static synchronized GestorReservas getInstancia() {
        if (instancia == null) { instancia = new GestorReservas(); }
        return instancia;
    }
    
    public void registrarReserva(Reserva r) { reservas.add(r); }
    public List<Reserva> getReservas() { return Collections.unmodifiableList(reservas); }
    
    public boolean eliminarPorDni(String dni) {
        return reservas.removeIf(r -> r.getCliente().getDni().equalsIgnoreCase(dni));
    }
    
    public void limpiarYcargar(List<Reserva> nuevasReservas) {
        reservas.clear();
        reservas.addAll(nuevasReservas);
    }
}
