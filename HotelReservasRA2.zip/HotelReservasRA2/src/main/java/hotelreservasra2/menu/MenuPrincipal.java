package hotelreservasra2.menu;

import hotelreservasra2.facade.SistemaHotelFacade;
import hotelreservasra2.util.Validaciones;
import hotelreservasra2.model.Cliente;
import hotelreservasra2.model.Reserva;
import hotelreservasra2.decorator.*; // Importa HabitacionBase, HabitacionSimple, HabitacionPremium y Decoradores
import hotelreservasra2.builder.*;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class MenuPrincipal {
    private final SistemaHotelFacade facade = new SistemaHotelFacade();
    private final Scanner sc = new Scanner(System.in);

    public MenuPrincipal() { 
        facade.inicializar(); 
    }

    public void iniciar() {
        int op;
        do {
            System.out.println("\n=============================================");
            System.out.println(" 1. Registrar Reserva");
            System.out.println(" 2. Mostrar Reservas");
            System.out.println(" 3. Eliminar Reserva por DNI");
            System.out.println(" 4. Mostrar Estructura del Hotel");
            System.out.println(" 5. Emitir Boleta de Venta");
            System.out.println(" 6. Salir");
            System.out.println("=============================================");
            op = Validaciones.leerEntero(sc, "Seleccione una opcion: ");
            procesar(op);
        } while(op != 6);
    }

    private void procesar(int op) {
        switch(op) {
            case 1 -> registrar();
            case 2 -> facade.mostrarReservas();
            case 3 -> eliminar();
            case 4 -> facade.mostrarEstructuraHotel();
            case 5 -> emitirBoleta();
            case 6 -> System.out.println("Gracias por usar el sistema. ¡Hasta luego!");
            default -> System.out.println("Opcion no valida. Intente de nuevo.");
        }
    }

    private void registrar() {
        System.out.println("\n--- REGISTRAR NUEVA RESERVA ---");
        
        // 1. Datos del Cliente
        System.out.print("Ingrese Nombre del cliente: "); 
        String nombre = sc.nextLine().trim();
        String dni;
        while (true) {
            System.out.print("Ingrese DNI del cliente (8 digitos): "); 
            dni = sc.nextLine().trim();
            if (dni.matches("\\d{8}")) break; 
            else System.out.println("[ERROR] DNI invalido.");
        }
        Cliente cliente = new Cliente(nombre, dni);

        // 2. Selección de Habitación (Dinámica)
        System.out.println("\nSeleccione el tipo de habitacion:");
        System.out.println("1. Simple (S/ 40.0)");
        System.out.println("2. Premium (S/ 80.0)");
        int tipoHab = Validaciones.leerEntero(sc, "Seleccione opcion: ");
        
        // Aquí aplicamos la lógica para elegir la base
        HabitacionBase hb = (tipoHab == 2) ? new HabitacionPremium() : new HabitacionSimple();

        // 3. Configuración de Extras (Decorator)
        System.out.println("\nConfiguracion de Servicios Adicionales:");
        System.out.print("-> Incluir Desayuno Buffet? (S/N): ");
        if (sc.nextLine().trim().equalsIgnoreCase("S")) hb = new DesayunoDecorator(hb);

        System.out.print("-> Incluir WiFi Premium? (S/N): ");
        if (sc.nextLine().trim().equalsIgnoreCase("S")) hb = new WifiDecorator(hb);

        System.out.print("-> Incluir Acceso al Spa? (S/N): ");
        if (sc.nextLine().trim().equalsIgnoreCase("S")) hb = new SpaDecorator(hb);

        // 4. Parámetros de la Estadía
        int noches = Validaciones.leerEntero(sc, "Ingrese numero de noches de estadia: ");
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate fechaIngreso = null;
        while (fechaIngreso == null) {
            System.out.print("Ingrese fecha de ingreso (DD/MM/AAAA): ");
            try { fechaIngreso = LocalDate.parse(sc.nextLine().trim(), formato); } 
            catch (DateTimeParseException e) { System.out.println("[ERROR] Formato incorrecto."); }
        }

        // 5. Construcción y persistencia
        ReservaBuilder builder = new ReservaConcretaBuilder();
        DirectorReserva director = new DirectorReserva(builder);
        Reserva nuevaReserva = director.construir(cliente, hb, "Efectivo", noches);
        
        nuevaReserva.setNumeroHabitacion(Validaciones.leerEntero(sc, "Num. HabitaciOn: "));
        nuevaReserva.setFechaIngreso(fechaIngreso.format(formato));
        nuevaReserva.setFechaSalida(fechaIngreso.plusDays(noches).format(formato));

        double total = hb.getCoste() * noches;
        facade.registrarReservaCompleta(nuevaReserva, 1, total);
        
        System.out.println("Reserva registrada con exito! Total calculado: S/ " + total);
    }

    private void eliminar() {
        System.out.print("Ingrese el DNI del cliente a eliminar: ");
        String dni = sc.nextLine().trim();
        if(facade.eliminarReservaPorDni(dni)) System.out.println("Reserva eliminada.");
        else System.out.println("No se encontro la reserva.");
    }

    private void emitirBoleta() {
        System.out.print("Ingrese DNI o numero de Boleta: ");
        facade.imprimirBoletaPorCriterio(sc.nextLine().trim());
    }
}