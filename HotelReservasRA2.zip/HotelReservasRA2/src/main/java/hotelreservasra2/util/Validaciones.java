package hotelreservasra2.util;
import java.util.Scanner;

public class Validaciones { 
    public static int leerEntero(Scanner sc, String msg) {
        System.out.print(msg);
        while(!sc.hasNextInt()) {
            System.out.print("Entrada invalida. " + msg);
            sc.next();
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }
}
