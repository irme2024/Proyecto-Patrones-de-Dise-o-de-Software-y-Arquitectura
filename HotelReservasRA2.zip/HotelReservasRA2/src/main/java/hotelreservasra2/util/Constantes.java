package hotelreservasra2.util;
public class Constantes { public static final String NOMBRE_HOTEL = "Hotel Paradiso Enterprise Edition"; }
