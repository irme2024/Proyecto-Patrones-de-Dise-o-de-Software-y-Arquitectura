package hotelreservasra2.decorator;

public class HabitacionPremium implements HabitacionBase {
    @Override
    public String getDescripcion() {
        return "Habitacion Premium";
    }

    @Override
    public double getCoste() {
        return 80.0;
    }
}