package hotelreservasra2.decorator;

public class SpaDecorator extends DecoradorHabitacion {
    public SpaDecorator(HabitacionBase h) { super(h); }

    @Override
    public String getDescripcion() { 
        return habitacionDecorada.getDescripcion() + " + Acceso Spa"; 
    }

    @Override
    public double getCoste() { 
        return habitacionDecorada.getCoste() + 15.0; // Precio Spa
    }
}