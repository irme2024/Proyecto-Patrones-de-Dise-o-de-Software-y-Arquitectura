package hotelreservasra2.decorator;
public class DesayunoDecorator extends DecoradorHabitacion {
    private static final long serialVersionUID = 1L;
    public DesayunoDecorator(HabitacionBase h) { super(h); }
    public String getDescripcion() { return super.getDescripcion() + " + Desayuno Buffet"; }
    public double getCoste() { return super.getCoste() + 25.0; }
}
