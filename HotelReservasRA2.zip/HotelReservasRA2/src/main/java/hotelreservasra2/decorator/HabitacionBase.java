package hotelreservasra2.decorator;
import java.io.Serializable;

public interface HabitacionBase extends Serializable {
    String getDescripcion();
    double getCoste();
}
