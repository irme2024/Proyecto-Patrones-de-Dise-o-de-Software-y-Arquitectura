package hotelreservasra2.decorator;

public class WifiDecorator extends DecoradorHabitacion {
    public WifiDecorator(HabitacionBase h) { super(h); }

    @Override
    public String getDescripcion() { 
        return habitacionDecorada.getDescripcion() + " + WiFi Premium"; 
    }

    @Override
    public double getCoste() { 
        return habitacionDecorada.getCoste() + 10.0; // Precio WiFi
    }
}