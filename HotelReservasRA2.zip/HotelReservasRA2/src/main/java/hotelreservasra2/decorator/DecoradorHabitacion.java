package hotelreservasra2.decorator;
public abstract class DecoradorHabitacion implements HabitacionBase {
    private static final long serialVersionUID = 1L;
    protected HabitacionBase habitacionDecorada;
    public DecoradorHabitacion(HabitacionBase h) { this.habitacionDecorada = h; }
    public String getDescripcion() { return habitacionDecorada.getDescripcion(); }
    public double getCoste() { return habitacionDecorada.getCoste(); }
}
