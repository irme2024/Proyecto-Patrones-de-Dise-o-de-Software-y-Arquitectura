package hotelreservasra2.decorator;
public class HabitacionSimple implements HabitacionBase {
    private static final long serialVersionUID = 1L;
    public String getDescripcion() { return "Habitacion Simple Estandar"; }
    public double getCoste() { return 80.0; }
}
