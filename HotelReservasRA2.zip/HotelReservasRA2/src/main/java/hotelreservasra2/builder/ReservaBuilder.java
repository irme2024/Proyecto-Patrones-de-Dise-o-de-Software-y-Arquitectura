package hotelreservasra2.builder;
import hotelreservasra2.model.Cliente;
import hotelreservasra2.model.Reserva;
import hotelreservasra2.decorator.HabitacionBase;

public interface ReservaBuilder {
    void buildCliente(Cliente cliente);
    void buildHabitacion(HabitacionBase habitacion);
    void buildMetodoPago(String metodoPago);
    void buildNoches(int noches);
    Reserva getReserva();
}
