package hotelreservasra2.builder;
import hotelreservasra2.model.Cliente;
import hotelreservasra2.model.Reserva;
import hotelreservasra2.decorator.HabitacionBase;

public class ReservaConcretaBuilder implements ReservaBuilder {
    private Reserva reserva;
    public ReservaConcretaBuilder() { this.reserva = new Reserva(); }
    public void buildCliente(Cliente cliente) { reserva.setCliente(cliente); }
    public void buildHabitacion(HabitacionBase habitacion) { reserva.setHabitacion(habitacion); }
    public void buildMetodoPago(String metodoPago) { reserva.setMetodoPago(metodoPago); }
    public void buildNoches(int noches) { reserva.setNoches(noches); }
    public Reserva getReserva() { 
        Reserva resultado = this.reserva;
        this.reserva = new Reserva();
        return resultado; 
    }
}
