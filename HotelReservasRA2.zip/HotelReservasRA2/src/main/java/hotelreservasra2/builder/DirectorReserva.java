package hotelreservasra2.builder;
import hotelreservasra2.model.Cliente;
import hotelreservasra2.model.Reserva;
import hotelreservasra2.decorator.HabitacionBase;

public class DirectorReserva {
    private ReservaBuilder builder;
    public DirectorReserva(ReservaBuilder builder) { this.builder = builder; }
    public Reserva construir(Cliente c, HabitacionBase h, String pago, int noches) {
        builder.buildCliente(c);
        builder.buildHabitacion(h);
        builder.buildMetodoPago(pago);
        builder.buildNoches(noches);
        return builder.getReserva();
    }
}
