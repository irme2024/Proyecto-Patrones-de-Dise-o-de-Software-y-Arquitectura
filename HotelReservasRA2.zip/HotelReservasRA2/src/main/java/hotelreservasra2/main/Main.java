package hotelreservasra2.main;
import hotelreservasra2.menu.MenuPrincipal;

public class Main {
    public static void main(String[] args) {
        new MenuPrincipal().iniciar();
    }
}
