package hotelreservasra2.persistencia;
import java.io.File;

public class UtilArchivo {
    public static void comprobarDirectorio(String ruta) {
        File folder = new File(ruta).getParentFile();
        if (folder != null && !folder.exists()) { folder.mkdirs(); }
    }
}
