package hotelreservasra2.persistencia;
import hotelreservasra2.model.Reserva;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoReservas {
    private static final String ARCHIVO_DAT = "data/reservas.dat";

    @SuppressWarnings("unchecked")
    public List<Reserva> cargarReservas() {
        File file = new File(ARCHIVO_DAT);
        if (!file.exists()) { return new ArrayList<>(); }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Reserva>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void guardarReservas(List<Reserva> lista) {
        UtilArchivo.comprobarDirectorio(ARCHIVO_DAT);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DAT))) {
            oos.writeObject(lista);
        } catch (IOException e) {
            System.out.println("Error al guardar persistencia: " + e.getMessage());
        }
    }
}
